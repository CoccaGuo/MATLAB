classdef OutputStream < Obj
    methods(Static)
        writeBytes(byteArray);
        close();
    end
end